<template>
    <h1>邮件内容</h1>
    <el-input style="width:80%" v-model="Content.TextContentList[0]"></el-input>
    <el-input style="width:80%" v-model="Content.TextContentList[1]"></el-input>
    <el-input style="width:80%" v-model="Content.AttachNameList"></el-input>
    <el-button @click="readMultipartFile(1)">读取附件1</el-button>
    <el-button @click="readMultipartFile(2)">读取附件2</el-button>
    <el-button @click="readMultipartFile(3)">读取附件3</el-button>

</template>

<script>
  import axios from 'axios'
  import { reactive } from 'vue';
  axios.defaults.headers.common["token"] = localStorage.getItem("token");

  export default{
    name:'getMailContent',
    data(){
      bodynum:""
      return{
        Content:{},
        ContentInfo:{},
      }
    },
    created(){
      this.readOtherContent();
      this.readContentInfo();
    },
    methods:{
      readOtherContent(){
        axios({
          url:"http://localhost:8080/readOtherContent",
          method:"post",
          data:{
            userName:localStorage.getItem("userName"),
            password:localStorage.getItem("password"),
            mailReceiveHost:"imap.163.com",
            msgnum:2,
            //msgnum:localStorage.getItem("nowRead"),
            protocal:1
            //protocal:localStorage.getItem("nowProtocal")
          },
          headers: {
            'Content-Type': 'application/json'
          }
        }).then((Response)=>{
          console.log(Response.data);
          this.Content=Response.data;
          console.log(this.Content);
        })
      },
      readContentInfo(){
        axios({
          url:"http://localhost:8080/getContentInfo",
          method:"post",
          data:{
            userName:localStorage.getItem("userName"),
            password:localStorage.getItem("password"),
            mailReceiveHost:"imap.163.com",
            msgnum:2,
            //msgnum:localStorage.getItem("nowRead"),
            protocal:1
            //protocal:localStorage.getItem("nowProtocal")
          },
          headers: {
            'Content-Type': 'application/json'
          }
        }).then((Response)=>{
          console.log("die");
          console.log(Response.data);
          this.ContentInfo=Response.data;
        })
      },
      readMultipartFile(val){
        axios({
          url:"http://localhost:8080/readMultipartContent",
          method:"post",
          responseType: "blob",
          data:{
            userName:localStorage.getItem("userName"),
            password:localStorage.getItem("password"),

            mailReceiveHost:"imap.163.com",
            msgnum:2,
            //msgnum:localStorage.getItem("nowRead"),
            protocal:1,
            //protocal:localStorage.getItem("nowProtocal")
            bodynum:val
          },
          headers: {
            'Content-Type': 'application/json'
          }
        }).then((Response)=>{
          console.log("读取附件");
          console.log(Response.data);
          const data = Response.data;
          let blob = new Blob([data]);
          const url = window.URL.createObjectURL(blob);
          const link = document.createElement("a");
          link.style.display = "none";
          link.href = url;
          link.setAttribute("download", Response.headers["content-disposition"].split("=")[1]);
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link)
        })
      }
    }
  }

</script>
