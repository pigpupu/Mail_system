<template>
  <h1>读取邮件</h1>
  <el-container>
    <el-header height="10px">
      <span>当前共有{{ InboxInfo.totalnum }}封邮件</span>
    </el-header>
    <el-main>
      <el-button @click="remove">remove</el-button>
      <el-button @click="forward">forward</el-button>
      <el-table ref="mailTable" :data="InboxInfo.simpleInfo" @selection-change="handleSelectionChange" style="width:100%;">
        <el-table-column label="序号" width="70">
         <template v-slot="scope">
         {{ scope.row.index = scope.$index+1 }}
         </template>
         </el-table-column>
        <el-table-column type="selection" width="55" />
        <el-table-column label="序号" width="180" align="left"> </el-table-column>
        <el-table-column property="receiveDate" label="Time" width="180" />
        <el-table-column property="subject" label="Sender" width="180" />
        <el-table-column property="address" label="Text" width="1020" />
      </el-table>
    </el-main>
  </el-container>
</template>

<script>
import axios from 'axios'
import { useRouter } from "vue-router"


axios.defaults.headers.common["token"] = localStorage.getItem("token");

/*var InboxInfo2=reactive({
  unReadNum:"",
  totalNum:"",
  simpleInfo:{
    ReplyTo:{
      address:"",
      personal:"",
      group:"",
      type:""
    },
    subject:"",
    receivDate:"",
    contentType:""
  },
  newMsgNum:"",
  alreadyDel:""
})*/

const router = useRouter();

export default{
  name:'receive',
  data(){
    return{
      InboxInfo:{},
      dataonLineListSelections: [],
    }
  },
  created(){
    this.getInboxInfo();
  },
  methods:{
    getInboxInfo(){
      axios({
        url:"http://localhost:8080/getInboxInfo",
        method:"post",
        data:{
          userName:localStorage.getItem("userName"),
          password:localStorage.getItem("password"),
          mailReceiveHost:"imap.163.com",//localStorage.getItem("mailSendHost")
          protocal:1
        },
        headers: {
          'Content-Type': 'application/json'
          //'Content-Type': 'multipart/form-data'
        }
      }).then((Response)=>{
        console.log(Response.data);
        this.InboxInfo=Response.data;
      })
    },
    forward(){
      router.push({path:"/mailcontent"})
    },
    remove(){

    },
    handleSelectionChange (val) {
       this.dataonLineListSelections = val
       console.log(val)
       console.log(InboxInfo.simpleInfo)
    },
    indexMethod(){}
  },


}


/*
var mailnum = ref("10")

var mailTable=ref("")

function remove() {
  var rows=[];
  rows=mailTable.value.getSelectionRows()
}

function forward() {

}

//need a function to cut the text

const mailData = [
  {
    id:1,
    date: '2016-05-03',
    name: 'Tom',
    text: 'No. 189, Grove St, Los Angeles tfyj uytfjuf yguik gkuy hgkjhgkjhgkjhgkjghkjhgkjgkhjgkjhgjgkjhgjkhgkjhgkhjgjhgkjkhgkjhgjkhgjhgkjhgkyug  giuy ikuygku gi86g i8yf 8i7',
  },
  {
    id:2,
    date: '2016-05-02',
    name: 'Tom',
    text: 'No. 189, Grove St, Los Angeles',
  },
  {
    id:3,
    date: '2016-05-04',
    name: 'Tom',
    text: 'No. 189, Grove St, Los Angeles',
  },
  {
    id:4,
    date: '2016-05-01',
    name: 'Tom',
    text: 'No. 189, Grove St, Los Angeles',
  },
  {
    id:5,
    date: '2016-05-08',
    name: 'Tom',
    text: 'No. 189, Grove St, Los Angeles',
  },
  {
    id:6,
    date: '2016-05-06',
    name: 'Tom',
    text: 'No. 189, Grove St, Los Angeles',
  },
  {
    id:7,
    date: '2016-05-07',
    name: 'Tom',
    text: 'No. 189, Grove St, Los Angeles',
  },

]*/

</script>
