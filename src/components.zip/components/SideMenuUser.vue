<template>
  <el-menu :default-active="route.path" :router="true">
    <el-menu-item index="/mailconfig">
      <template #title>
        <el-icon>
          <EditPen />
        </el-icon>
        <span>config</span>
      </template>
    </el-menu-item>
    <el-menu-item index="/write">
      <el-icon>
        <EditPen />
      </el-icon>
      <span>Write letter</span>
    </el-menu-item>
    <el-menu-item index="/recieve">
      <template #title>
        <el-icon>
          <Message />
        </el-icon>
        <span>Recieve letter</span>
      </template>
    </el-menu-item>

  </el-menu>
</template>

<script setup>
import { useRoute } from 'vue-router'
import { EditPen, Message} from '@element-plus/icons-vue';

const route = useRoute();

</script>

<style scoped>

.el-menu {
  height: 100%;
}

</style>
