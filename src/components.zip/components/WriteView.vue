<template>
  <el-container>
    <el-header style="display:flex">
      <el-button @click="send">send</el-button>
      <el-button @click="save">save</el-button>
      <el-button @click="close">close</el-button>
    </el-header>
    <el-main>
      <el-form label-width="60px" label-position="left" :model="r.letterForm">
        <el-form-item label="收件人">
          <el-input style="width:80%" v-model="r.letterForm.tos"></el-input>
        </el-form-item>
        <el-form-item label="主题">
          <el-input style="width:80%" v-model="r.letterForm.subject"></el-input>
        </el-form-item>
        <el-form-item label="正文">
          <el-input style="width:80%" type="textarea" :rows="30" v-model="r.letterForm.textContent"></el-input>
        </el-form-item>
      </el-form>
    </el-main>
  </el-container>
</template>

<script setup>
import axios from 'axios'
import { reactive } from 'vue';



var r = reactive({
  letterForm: {
    tos: "",
    subject: "",
    textContent: "",
    file: "",
  }
})

axios.defaults.headers.common["token"] = localStorage.getItem("token");

function send() {
  axios({
    url:"http://localhost:8080/basicSend",
    method:'post',
    data:{
      mailSendHost:localStorage.getItem("mailSendHost"),
      userName:localStorage.getItem("userName"),
      password:localStorage.getItem("password"),
      tos:r.letterForm.tos,
      subject:r.letterForm.subject,
      textContent:r.letterForm.textContent
    },
    headers: {
      //'Content-Type': 'application/json'
      'Content-Type': 'multipart/form-data'
    }
  }).then((Response)=>{
    console.log(Response.data);
    console.log(Response.data.code)
    if(Response.data.code=200){
      alert("send success")
    }else{
      alert("send failed")
    }
  })
}

function save() {
  r.letterForm.tos="";
  r.letterForm.subject="";
  r.letterForm.textContent="";
}

function close() {

}

</script>

<style scoped>


</style>
